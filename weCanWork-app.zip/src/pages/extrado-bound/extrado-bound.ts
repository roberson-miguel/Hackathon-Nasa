import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-extrado-bound',
  templateUrl: 'extrado-bound.html'
})
export class ExtradoBoundPage {

  constructor(public navCtrl: NavController) {
  }
  
}
