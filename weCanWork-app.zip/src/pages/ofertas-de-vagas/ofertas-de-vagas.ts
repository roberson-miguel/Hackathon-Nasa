import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Perfil2Page } from '../perfil2/perfil2';
import { PerfilPage } from '../perfil/perfil';
import { Questionario110Page } from '../questionario110/questionario110';
import { ParabNsPage } from '../parab-ns/parab-ns';
import { ExtradoBoundPage } from '../extrado-bound/extrado-bound';
import { OfertasDeVagasPage } from '../ofertas-de-vagas/ofertas-de-vagas';

@Component({
  selector: 'page-ofertas-de-vagas',
  templateUrl: 'ofertas-de-vagas.html'
})
export class OfertasDeVagasPage {

  constructor(public navCtrl: NavController) {
  }
  goToPerfil2(params){
    if (!params) params = {};
    this.navCtrl.push(Perfil2Page);
  }goToPerfil(params){
    if (!params) params = {};
    this.navCtrl.push(PerfilPage);
  }goToQuestionario110(params){
    if (!params) params = {};
    this.navCtrl.push(Questionario110Page);
  }goToParabNs(params){
    if (!params) params = {};
    this.navCtrl.push(ParabNsPage);
  }goToExtradoBound(params){
    if (!params) params = {};
    this.navCtrl.push(ExtradoBoundPage);
  }goToOfertasDeVagas(params){
    if (!params) params = {};
    this.navCtrl.push(OfertasDeVagasPage);
  }
}
