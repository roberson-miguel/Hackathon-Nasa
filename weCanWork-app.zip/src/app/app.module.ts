import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { TabsControllerPage } from '../pages/tabs-controller/tabs-controller';
import { PerfilPage } from '../pages/perfil/perfil';
import { CadastroPage } from '../pages/cadastro/cadastro';
import { Page6Page } from '../pages/page6/page6';
import { Perfil2Page } from '../pages/perfil2/perfil2';
import { Questionario110Page } from '../pages/questionario110/questionario110';
import { HomePage } from '../pages/home/home';
import { ExtradoBoundPage } from '../pages/extrado-bound/extrado-bound';
import { ParabNsPage } from '../pages/parab-ns/parab-ns';
import { OfertasDeVagasPage } from '../pages/ofertas-de-vagas/ofertas-de-vagas';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    TabsControllerPage,
    PerfilPage,
    CadastroPage,
    Page6Page,
    Perfil2Page,
    Questionario110Page,
    HomePage,
    ExtradoBoundPage,
    ParabNsPage,
    OfertasDeVagasPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TabsControllerPage,
    PerfilPage,
    CadastroPage,
    Page6Page,
    Perfil2Page,
    Questionario110Page,
    HomePage,
    ExtradoBoundPage,
    ParabNsPage,
    OfertasDeVagasPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}